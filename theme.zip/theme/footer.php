<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content
 * after.  Calls sidebar-footer.php for bottom widgets.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */
 $options = get_option('cOptn');
 
  $options['copyright']
?>


   
<?php wp_footer(); ?>

<div class="footer">
<div class="copyright">All Rights Reserved</div>
</div>

</body>
</html>

    
