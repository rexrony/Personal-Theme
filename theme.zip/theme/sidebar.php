<?php /* ?>

 <?php $welcome = new WP_Query('category_name=services&showposts=1&order=ASC'); ?> 
  <?php while( $welcome->have_posts() ) : $welcome->the_post();  ?> 
  
  
  <?php endwhile; ?>

<?php */ ?>